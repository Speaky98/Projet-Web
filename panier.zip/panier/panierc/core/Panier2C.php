<?php 
	include "config2.php";
	class Panier2C{
		function ajouterPanier2($cart){
			$sql="insert into panier2 (id,quantite) values (:id,:quantite)";

			$db1 = configpa2::getConnexion();
			try{
        	$req=$db1->prepare($sql);

        	$id_pro=$cart->getid_pro();
        	$email=$cart->getemail();
        	$quantite=$cart->getquantite();
        	$status=$cart->getstatus();
        	$date=$cart->getdate();

			$req->bindValue(':id_pro',$id_pro);
		    $req->bindValue(':quantite',$quantite);
		

            $req->execute();
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
	}
	function getPros2(){

		$sql="SElECT * From panier2 WHERE id='$idp'";
		$db = configpa2::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function afficherPaniers2(){

		$sql="SElECT * From panier2";
		$db = configpa2::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function afficherPanier2Cs($id){

		$sql="SElECT * From panier2 id='$id'";
		$db = configpa::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function supprimerPro2($id_pro){
		$sql="DELETE FROM panier2 where id= :id";
		$db1 = configpa2::getConnexion();
        $req=$db1->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function supprimerProMail2($id){
		$sql="DELETE FROM panier2 where id= :id;
		$db1 = configpa2::getConnexion();
        $req=$db1->prepare($sql);
		$req->bindValue(':id',$id_pro);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function updatequantity($quantite){
		$sql="UPDATE panier SET quantite=:quantite where quantite=:quantite";
		
		$db = configc::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{
		$req->bindValue(':quantite',$quantite);
		
        $s=$req->execute();
			
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
  
        }
	}
}
?>