<?PHP
class Panier2
{
	private $id;
	private $quantite;
	private $prix;
	function __construct($id,$quantite){
		$this->id=$id;
	    $this->quantite=$quantite;	
	}
	
	function getid(){
		return $this->id;
	}
	function getquantite(){
		return $this->quantite;
	}

}

?>