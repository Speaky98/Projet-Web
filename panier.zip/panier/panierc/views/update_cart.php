<?php
	echo $_POST['qte'];
?>
