<?php
session_start();
include "../../produit/entities/produit.php";
include "../../produit/core/ProduitC.php";
include "../entities/panier.php";
include "../core/PanierC.php";


$prodC = new ProduitC();
$listeProduits = $prodC->afficherProduits();


$paC=new PanierC();
$listep=$paC->afficherPaniers();
$i=0;
$j=0;
$total=0;
$pro=0;
foreach ($listeProduits as $lu) {
	if($lu['id']==$_GET['produit']) $qte=$lu['quantite'];
} 
foreach ($listep as $row) {
	if(($row['id']==$_GET['produit']))
		{
			$total=$row['quantite']+$_POST['qte'];
			$pro++;
		}
}
if($pro==0){
		$_SESSION['cart']=$_SESSION['cart']+1;
		if($qte > $_POST['qte']){
		$par=new Panier($_GET['pro'],$_POST['qte'],"no");
		$paC->ajouterPanier($par);
		header('Location: ../../produit/views/boutique.php?niveau=0');
	}
	else{
		header('Location: ../../produit/views/boutique.php?niveau=0');
	}
}

?>