<?php 
	include "config2.php";
	class Panier2C{
		function ajouterPanier2($cart){
			$sql="insert into panier2 (id_produit,quantite) values (:id_produit,:quantite)";

			$db1 = configpa2::getConnexion();
			try{
        	$req=$db1->prepare($sql);

        	$id_pro=$cart->getid_produit();
        	$quantite=$cart->getquantite();


			$req->bindValue(':id_produit',$id_produit);
			$req->bindValue(':quantite',$quantite);


            $req->execute();
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
	}
	function getPros2(){

		$sql="SElECT * From panier2 WHERE id_produit='$idproduit'";
		$db = configpa2::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function afficherPaniers2(){

		$sql="SElECT * From panier2";
		$db = configpa2::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function afficherPanier2Cs($idp){

		$sql="SElECT * From panier2 WHERE id_pro='$idp'";
		$db = configpa::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function supprimerPro2($id_pro){
		$sql="DELETE FROM panier2 where id_produit= :id_produit";
		$db1 = configpa2::getConnexion();
        $req=$db1->prepare($sql);
		$req->bindValue(':id_produit',$id_produit);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function supprimerPanier($email){
		$sql="DELETE * FROM panier2 where produit= :produit";
		$db1 = configpa2::getConnexion();
        $req=$db1->prepare($sql);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function updatequantity($quantite){
		$sql="UPDATE panier SET quantite=:quantite where quantite=:quantite";
		
		$db = configc::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{
		$req->bindValue(':quantite',$quantite);
		
        $s=$req->execute();
			
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
	}
}
?>