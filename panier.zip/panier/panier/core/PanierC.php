<?php 
	include "config.php";
	class PanierC{
		function ajouterPanier($cart){
			$sql="insert into panier (id,quantite) values (:id,:quantite)";

			$db1 = configpa::getConnexion();
			try{
        	$req=$db1->prepare($sql);

        	$id=$cart->getid();
        	$quantite=$cart->getquantite();
        	


			$req->bindValue(':id',$id);
			$req->bindValue(':quantite',$quantite);
			
			
            $req->execute();
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
	}
	
	function afficherPaniers(){

		$sql="SElECT * From panier";
		$db = configpa::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function supprimerPro($id_produit){
		$sql="DELETE FROM panier where id= :id";
		$db1 = configpa::getConnexion();
        $req=$db1->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function updatequantity($quantite){
		$sql="UPDATE panier SET quantite=:quantite where quantite=:quantite";
		
		$db = configc::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{
		$req->bindValue(':quantite',$quantite);
		
        $s=$req->execute();
			
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
	}
	
}
?>