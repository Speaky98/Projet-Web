<?php
session_start();
include "../../produit/entities/produit.php";
include "../../produit/core/ProduitC.php";
include "../entities/panier.php";
include "../core/PanierC.php";


$prodC = new ProduitC();
$listeProduits = $prodC->afficherProduits();


$paC=new PanierC();
$listep=$paC->afficherPaniers();
$i=0;
$j=0;
$total=0;
$pro=0;
foreach ($listeProduits as $lu) {
	if($lu['id']==$_GET['produit']) $qte=$lu['quantite'];
} 
foreach ($listep as $row) {
	if(($row['id']==$_GET['produit'])
		{
			$total=$row['quantite']+1;
			$pro++;
		}
}
if($pro==0){
		$total=1;
		$_SESSION['cart']=$_SESSION['cart']+1;
		if($qte > 1){
		$par=new Panier($_GET['produit'],$total,"no");
		$paC->ajouterPanier($par);
		header('Location: ../../produit/views/boutique.php?niveau=0');
	}
	else{
		header('Location: ../../produit/views/boutique.php?niveau=0');
	}
}
else {
	if($qte > 1){

		
		$par=new Panier($_GET['produit'],$total,"no");
		echo "OK";
		$paC->ajouterPanier($par);
		header('Location: ../../produit/views/boutique.php?niveau=0');
	}
	else{

	}
}
?>